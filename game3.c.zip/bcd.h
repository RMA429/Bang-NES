
unsigned int bcd_add(unsigned int a, unsigned int b);
unsigned int bcd_add2(unsigned int a, unsigned int b);
