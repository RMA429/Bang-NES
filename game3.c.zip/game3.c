
#include <stdlib.h>
#include <string.h>

#include <stdlib.h>
#include <string.h>

// include NESLIB header
#include "neslib.h"

// include CC65 NES Header (PPU)
#include <nes.h>

// link the pattern table into CHR ROM
//#link "chr_generic.s"

// BCD arithmetic support
#include "bcd.h"
//#link "bcd.c"

// VRAM update buffer
#include "vrambuf.h"
//#link "vrambuf.c"

// Walking Metasprites
const unsigned char stand1[]={
  0,	0,	0xc4,	0,
  0,	8,	0xc4+1,	0,
  8,	0,	0xc4+2,	0,
  8,	8,	0xc4+3,	0,
128};

const unsigned char walk1[]={
  0,	0,	0xc8,	0,
  0,	8,	0xc8+1,	0,
  8,	0,	0xc8+2,	0,
  8,	8,	0xc8+3,	0,
128};

const unsigned char walk2[] ={
  0,	0,	0xe8,	0,
  0,	8,	0xe8+1,	0,
  8,	0,	0xe8+2,	0,
  8,	8,	0xe8+3,	0,
128};

const unsigned char walk3[]={
  0,	0,	0xcc,	0,
  0,	8,	0xcc+1,	0,
  8,	0,	0xcc+2,	0,
  8,	8,	0xcc+3,	0,
128};

const unsigned char walk1LEFT[]={
  0,	0,	0xc8,	(0)|OAM_FLIP_H,
  0,	8,	0xc8+1,	(0)|OAM_FLIP_H,
  8,	0,	0xc8+2,	(0)|OAM_FLIP_H,
  8,	8,	0xc8+3,	(0)|OAM_FLIP_H,
128};

const unsigned char walk2LEFT[]={
  0,	0,	0xe8,	(0)|OAM_FLIP_H,
  0,	8,	0xe8+1,	(0)|OAM_FLIP_H,
  8,	0,	0xe8+2,	(0)|OAM_FLIP_H,
  8,	8,	0xe8+3,	(0)|OAM_FLIP_H,
128};

const unsigned char walk3LEFT[]={
  0,	0,	0xcc,	(0)|OAM_FLIP_H,
  0,	8,	0xcc+1,	(0)|OAM_FLIP_H,
  8,	0,	0xcc+2,	(0)|OAM_FLIP_H,
  8,	8,	0xcc+3,	(0)|OAM_FLIP_H,
128};

// Misc. Item Metasprites

const unsigned char spike[]={
  0,	0,	0xd0,	2,
  0,	8,	0xd0+1,	2,
  8,	0,	0xd0+2,	2,
  8,	8,	0xd0+3,	2,
128};

const unsigned char block[]={
  0,	0,	0xd4,	1,
  0,	8,	0xd4+1,	1,
  8,	0,	0xd4+2,	1,
  8,	8,	0xd4+3,	1,
128};

// Metasprite Sequence
const unsigned char * const walkSeq[16] = {
  walk1LEFT, walk2LEFT, walk3LEFT,
  walk1LEFT, walk2LEFT, walk3LEFT,
  walk1LEFT, walk2LEFT,
  walk1, walk2, walk3,
  walk1, walk2, walk3,
  walk1, walk2
};

/*{pal:"nes",layout:"nes"}*/
const char PALETTE[32] = { 
  0x0C,			// screen color

  0x01,0x10,0x21,0x00,	// background palette 0
  0x1C,0x20,0x2C,0x00,	// background palette 1
  0x00,0x10,0x20,0x00,	// background palette 2
  0x06,0x16,0x26,0x00,   // background palette 3

  0x27,0x10,0x21,0x00,	// sprite palette 0
  0x01,0x3D,0x26,0x00,	// sprite palette 1
  0x3D,0x2D,0x16,0x00,	// sprite palette 2
  0x1D,0x32,0x24	// sprite palette 3
};

// Define directive to create
// positioning arrays for our actors.
#define NUM_ACTORS 16
byte actor_x[NUM_ACTORS];
byte actor_y[NUM_ACTORS];
sbyte actor_dx[NUM_ACTORS];
sbyte actor_dy[NUM_ACTORS];

typedef struct {
  byte xpos;
  byte ypos;
  signed char dxpos;
  signed char dypos;
} softBlock;

typedef struct {
  byte xpos;
  byte ypos;
  signed char dxpos;
  signed char dypos;
} hardBlock;


// Global Zone above
//////////////////////////////////////////////////////////////////////////////////////////

  
void actorHandle(char num)
{
  char oam_id;
  oam_id = num;
  actor_x[num] -= 1;
  oam_id = oam_meta_spr(actor_x[num], actor_y[num], oam_id, walkSeq[7]);
}

void setup_guys()
{
  actor_x[0] = 30;
  actor_y[0] = 180;
  actor_dx[0] = 0;
  actor_dy[0] = 0;
}

void scrollNext(void)
{
  int x = 0;
  int y = 0; 
  int dx = 1;
  int countdown = 220;
  while (countdown > 0)
  {
    ppu_wait_frame();
    x += dx;
    actorHandle(0);
    scroll(x, y);
    countdown--;
  }
}

void wallCheck(void)
{
  if( actor_x[0] >= 235)
  {
    scrollNext();
  }
}

void move_guys(char pad)
{
  if(pad&PAD_RIGHT && actor_x[0]<240)
  {
    actor_dx[0] = 2;
  }
  else if(pad&PAD_LEFT && actor_x[0]>0)
  {
    actor_dx[0] = -2;
  }
  else
  {
    actor_dx[0] = 0;
  }
}

// setup PPU and tables
void setup_graphics() {
  // use to clear sprites
  oam_hide_rest(0);
  oam_clear();
  // set palette colors
  pal_all(PALETTE);
  //pal_bg(PALETTE);
  vram_adr(NAMETABLE_A);
  vram_fill(0x6, 32*24);	// fill nametable up to feet of BANG!
  vram_fill(0xd4, 4*32);
  // enable rendering
  ppu_on_all();
}


void main(void)
{
  char pad;
  char oam_id;
  byte animSeq;
  
  setup_graphics();

  // Set up guy
  setup_guys();
  
  while(1) 
  {
    oam_id = 0;
    pad = pad_poll(0);
    move_guys(pad);
    animSeq = actor_x[0] & 7;
    if (actor_dx[0] >= 0)
    {
      animSeq += 8;
    }
    oam_id = oam_meta_spr(actor_x[0], actor_y[0], oam_id, walkSeq[animSeq]);
    actor_x[0] += actor_dx[0];
    wallCheck();
    ppu_wait_frame();
  }
  
}
